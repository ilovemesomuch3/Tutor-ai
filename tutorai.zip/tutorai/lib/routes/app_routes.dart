import 'package:flutter/material.dart';

import '../presentation/history_screen/history_screen.dart';
import '../presentation/home_screen/home_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String homeScreen = '/home-screen';
  static const String learnScreen = '/learn-screen';
  static const String historyScreen = '/history-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const HomeScreen(),
    homeScreen: (context) => const HomeScreen(),
    historyScreen: (context) => const HistoryScreen(),
  };
}