
import '../core/app_export.dart';

enum LessonStatus { completed, inProgress, notStarted, reviewing }

class StatusBadgeWidget extends StatelessWidget {
  final LessonStatus status;

  const StatusBadgeWidget({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    final config = _getConfig(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: config.bgColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        config.label,
        style: GoogleFonts.manrope(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: config.textColor,
          letterSpacing: 0.2,
        ),
      ),
    );
  }

  _BadgeConfig _getConfig(LessonStatus status) {
    switch (status) {
      case LessonStatus.completed:
        return _BadgeConfig(
          label: 'Completed',
          bgColor: AppTheme.successContainer,
          textColor: AppTheme.success,
        );
      case LessonStatus.inProgress:
        return _BadgeConfig(
          label: 'In Progress',
          bgColor: AppTheme.primaryContainer,
          textColor: AppTheme.primary,
        );
      case LessonStatus.notStarted:
        return _BadgeConfig(
          label: 'Not Started',
          bgColor: const Color(0xFFF3F4F6),
          textColor: AppTheme.textSecondary,
        );
      case LessonStatus.reviewing:
        return _BadgeConfig(
          label: 'Reviewing',
          bgColor: AppTheme.warningContainer,
          textColor: AppTheme.warning,
        );
    }
  }
}

class ScoreBadgeWidget extends StatelessWidget {
  final int score;

  const ScoreBadgeWidget({super.key, required this.score});

  @override
  Widget build(BuildContext context) {
    Color bgColor;
    Color textColor;
    if (score >= 80) {
      bgColor = AppTheme.successContainer;
      textColor = AppTheme.success;
    } else if (score >= 60) {
      bgColor = AppTheme.warningContainer;
      textColor = AppTheme.warning;
    } else {
      bgColor = AppTheme.errorContainer;
      textColor = AppTheme.errorColor;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        '$score%',
        style: GoogleFonts.manrope(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: textColor,
          fontFeatures: const [FontFeature.tabularFigures()],
        ),
      ),
    );
  }
}

class _BadgeConfig {
  final String label;
  final Color bgColor;
  final Color textColor;
  _BadgeConfig({
    required this.label,
    required this.bgColor,
    required this.textColor,
  });
}
