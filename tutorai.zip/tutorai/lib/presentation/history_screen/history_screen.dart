
import '../../core/app_export.dart';
import './widgets/history_chart_widget.dart';
import './widgets/history_filter_widget.dart';
import './widgets/history_lesson_list_widget.dart';
import './widgets/history_stats_summary_widget.dart';

// TODO: Replace with Riverpod/Bloc for production state management
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  int _currentNavIndex = 2;
  String _activeFilter = 'All';

  void _onNavTap(int index) {
    if (index == _currentNavIndex) return;
    setState(() => _currentNavIndex = index);
    switch (index) {
      case 0:
        Navigator.pushNamedAndRemoveUntil(
          context,
          AppRoutes.homeScreen,
          (r) => false,
        );
        break;
      case 1:
        Navigator.pushNamedAndRemoveUntil(
          context,
          AppRoutes.learnScreen,
          (r) => false,
        );
        break;
      case 2:
        break;
    }
  }

  void _onFilterChanged(String filter) {
    setState(() => _activeFilter = filter);
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      bottomNavigationBar: isTablet
          ? null
          : AppNavigation(
              currentIndex: _currentNavIndex,
              onDestinationSelected: _onNavTap,
            ),
      body: SafeArea(
        child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return Column(
      children: [
        const SizedBox(height: 8),
        FloatingAppBarWidget(
          title: 'History',
          actions: [
            IconButton(
              icon: const Icon(
                Icons.tune_rounded,
                color: AppTheme.textPrimary,
                size: 20,
              ),
              onPressed: () {},
              splashRadius: 20,
            ),
          ],
        ),
        const SizedBox(height: 8),
        Expanded(
          child: RefreshIndicator(
            color: AppTheme.primary,
            onRefresh: () async {
              await Future.delayed(const Duration(milliseconds: 800));
            },
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: HistoryStatsSummaryWidget(),
                      ),
                      const SizedBox(height: 20),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: HistoryChartWidget(),
                      ),
                      const SizedBox(height: 20),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: HistoryFilterWidget(
                          activeFilter: _activeFilter,
                          onFilterChanged: _onFilterChanged,
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  sliver: HistoryLessonListWidget(activeFilter: _activeFilter),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 100)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      children: [
        AppNavigation(
          currentIndex: _currentNavIndex,
          onDestinationSelected: _onNavTap,
        ),
        const VerticalDivider(width: 1),
        Expanded(
          child: Column(
            children: [
              const SizedBox(height: 8),
              FloatingAppBarWidget(
                title: 'History',
                actions: [
                  IconButton(
                    icon: const Icon(
                      Icons.tune_rounded,
                      color: AppTheme.textPrimary,
                      size: 20,
                    ),
                    onPressed: () {},
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Left: chart + stats
                    Expanded(
                      flex: 4,
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            const HistoryStatsSummaryWidget(),
                            const SizedBox(height: 20),
                            const HistoryChartWidget(),
                          ],
                        ),
                      ),
                    ),
                    Container(width: 1, color: const Color(0xFFE9E8F8)),
                    // Right: filter + list
                    Expanded(
                      flex: 6,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                            child: HistoryFilterWidget(
                              activeFilter: _activeFilter,
                              onFilterChanged: _onFilterChanged,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Expanded(
                            child: CustomScrollView(
                              slivers: [
                                SliverPadding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                  ),
                                  sliver: HistoryLessonListWidget(
                                    activeFilter: _activeFilter,
                                  ),
                                ),
                                const SliverToBoxAdapter(
                                  child: SizedBox(height: 40),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
