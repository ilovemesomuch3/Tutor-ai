
import '../../../core/app_export.dart';

class _HistoryLesson {
  final String id;
  final String title;
  final String subject;
  final String subjectEmoji;
  final int score;
  final String date;
  final String duration;
  final LessonStatus status;
  final int questionsTotal;
  final int questionsCorrect;

  const _HistoryLesson({
    required this.id,
    required this.title,
    required this.subject,
    required this.subjectEmoji,
    required this.score,
    required this.date,
    required this.duration,
    required this.status,
    required this.questionsTotal,
    required this.questionsCorrect,
  });
}

class HistoryLessonListWidget extends StatefulWidget {
  final String activeFilter;

  const HistoryLessonListWidget({super.key, required this.activeFilter});

  @override
  State<HistoryLessonListWidget> createState() =>
      _HistoryLessonListWidgetState();
}

class _HistoryLessonListWidgetState extends State<HistoryLessonListWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _staggerController;
  final List<Animation<double>> _itemAnimations = [];

  static final List<Map<String, dynamic>> _lessonMaps = [
    {
      'id': 'l1',
      'title': 'Photosynthesis & Cellular Respiration',
      'subject': 'Biology',
      'subjectEmoji': '🌱',
      'score': 88,
      'date': 'Apr 21, 2026',
      'duration': '18 min',
      'status': 'completed',
      'questionsTotal': 5,
      'questionsCorrect': 4,
    },
    {
      'id': 'l2',
      'title': 'World War II — Causes & Effects',
      'subject': 'History',
      'subjectEmoji': '📜',
      'score': 64,
      'date': 'Apr 20, 2026',
      'duration': '22 min',
      'status': 'reviewing',
      'questionsTotal': 5,
      'questionsCorrect': 3,
    },
    {
      'id': 'l3',
      'title': 'Quadratic Equations & Factoring',
      'subject': 'Maths',
      'subjectEmoji': '📐',
      'score': 55,
      'date': 'Apr 19, 2026',
      'duration': '30 min',
      'status': 'reviewing',
      'questionsTotal': 5,
      'questionsCorrect': 2,
    },
    {
      'id': 'l4',
      'title': 'Newton\'s Laws of Motion',
      'subject': 'Physics',
      'subjectEmoji': '⚡',
      'score': 92,
      'date': 'Apr 18, 2026',
      'duration': '14 min',
      'status': 'completed',
      'questionsTotal': 5,
      'questionsCorrect': 5,
    },
    {
      'id': 'l5',
      'title': 'The French Revolution',
      'subject': 'History',
      'subjectEmoji': '📜',
      'score': 78,
      'date': 'Apr 17, 2026',
      'duration': '20 min',
      'status': 'completed',
      'questionsTotal': 5,
      'questionsCorrect': 4,
    },
    {
      'id': 'l6',
      'title': 'Acids, Bases and pH Scale',
      'subject': 'Chemistry',
      'subjectEmoji': '⚗️',
      'score': 62,
      'date': 'Apr 16, 2026',
      'duration': '25 min',
      'status': 'reviewing',
      'questionsTotal': 5,
      'questionsCorrect': 3,
    },
    {
      'id': 'l7',
      'title': 'DNA Structure and Replication',
      'subject': 'Biology',
      'subjectEmoji': '🌱',
      'score': 55,
      'date': 'Apr 15, 2026',
      'duration': '28 min',
      'status': 'reviewing',
      'questionsTotal': 5,
      'questionsCorrect': 2,
    },
    {
      'id': 'l8',
      'title': 'Simultaneous Equations',
      'subject': 'Maths',
      'subjectEmoji': '📐',
      'score': 80,
      'date': 'Apr 14, 2026',
      'duration': '16 min',
      'status': 'completed',
      'questionsTotal': 5,
      'questionsCorrect': 4,
    },
  ];

  late List<_HistoryLesson> _allLessons;
  late List<_HistoryLesson> _filteredLessons;

  static LessonStatus _statusFromString(String s) {
    switch (s) {
      case 'completed':
        return LessonStatus.completed;
      case 'reviewing':
        return LessonStatus.reviewing;
      case 'inProgress':
        return LessonStatus.inProgress;
      default:
        return LessonStatus.notStarted;
    }
  }

  static _HistoryLesson _fromMap(Map<String, dynamic> map) {
    return _HistoryLesson(
      id: map['id'] as String,
      title: map['title'] as String,
      subject: map['subject'] as String,
      subjectEmoji: map['subjectEmoji'] as String,
      score: map['score'] as int,
      date: map['date'] as String,
      duration: map['duration'] as String,
      status: _statusFromString(map['status'] as String),
      questionsTotal: map['questionsTotal'] as int,
      questionsCorrect: map['questionsCorrect'] as int,
    );
  }

  @override
  void initState() {
    super.initState();
    _allLessons = _lessonMaps.map(_fromMap).toList();
    _filteredLessons = _allLessons;

    _staggerController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    );
    _buildAnimations(_allLessons.length);
    _staggerController.forward();
  }

  void _buildAnimations(int count) {
    _itemAnimations.clear();
    for (int i = 0; i < count; i++) {
      final start = (i * 0.1).clamp(0.0, 0.85);
      final end = (start + 0.3).clamp(0.0, 1.0);
      _itemAnimations.add(
        Tween<double>(begin: 0, end: 1).animate(
          CurvedAnimation(
            parent: _staggerController,
            curve: Interval(start, end, curve: Curves.easeOutCubic),
          ),
        ),
      );
    }
  }

  @override
  void didUpdateWidget(HistoryLessonListWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.activeFilter != widget.activeFilter) {
      setState(() {
        if (widget.activeFilter == 'All') {
          _filteredLessons = _allLessons;
        } else {
          _filteredLessons = _allLessons
              .where((l) => l.subject == widget.activeFilter)
              .toList();
        }
        _buildAnimations(_filteredLessons.length);
        _staggerController
          ..reset()
          ..forward();
      });
    }
  }

  @override
  void dispose() {
    _staggerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_filteredLessons.isEmpty) {
      return const SliverToBoxAdapter(
        child: SizedBox(
          height: 200,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.search_off_rounded,
                  size: 48,
                  color: Color(0xFFD1D5DB),
                ),
                SizedBox(height: 12),
                Text(
                  'No lessons found for this subject',
                  style: TextStyle(fontSize: 14, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate((context, index) {
        if (index >= _filteredLessons.length) return null;
        final lesson = _filteredLessons[index];
        final anim = index < _itemAnimations.length
            ? _itemAnimations[index]
            : const AlwaysStoppedAnimation(1.0);

        return AnimatedBuilder(
          animation: anim,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, 20 * (1 - anim.value)),
              child: Opacity(opacity: anim.value, child: child),
            );
          },
          child: Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _HistoryLessonCard(lesson: lesson),
          ),
        );
      }, childCount: _filteredLessons.length),
    );
  }
}

class _HistoryLessonCard extends StatelessWidget {
  final _HistoryLesson lesson;
  const _HistoryLessonCard({required this.lesson});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final pct = lesson.score;
    final isWeak = pct < 60;

    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(16),
      splashColor: AppTheme.primaryMuted,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isWeak
                ? AppTheme.errorColor.withAlpha(77)
                : theme.colorScheme.outline.withAlpha(102),
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: isWeak
                          ? AppTheme.errorContainer
                          : AppTheme.primaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        lesson.subjectEmoji,
                        style: const TextStyle(fontSize: 20),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          lesson.title,
                          style: theme.textTheme.titleSmall,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 7,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.surfaceVariantColor,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                lesson.subject,
                                style: GoogleFonts.manrope(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              lesson.date,
                              style: theme.textTheme.labelSmall,
                            ),
                            const SizedBox(width: 6),
                            Text('·', style: theme.textTheme.labelSmall),
                            const SizedBox(width: 6),
                            const Icon(
                              Icons.timer_outlined,
                              size: 11,
                              color: AppTheme.textSecondary,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              lesson.duration,
                              style: theme.textTheme.labelSmall,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  ScoreBadgeWidget(score: lesson.score),
                ],
              ),
            ),
            Container(
              height: 1,
              color: theme.colorScheme.outline.withAlpha(51),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  _QuestionsIndicator(
                    correct: lesson.questionsCorrect,
                    total: lesson.questionsTotal,
                  ),
                  const Spacer(),
                  StatusBadgeWidget(status: lesson.status),
                  const SizedBox(width: 10),
                  OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppTheme.primary,
                      side: BorderSide(color: AppTheme.primary.withAlpha(102)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      textStyle: GoogleFonts.manrope(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    child: const Text('Review'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuestionsIndicator extends StatelessWidget {
  final int correct;
  final int total;

  const _QuestionsIndicator({required this.correct, required this.total});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ...List.generate(total, (i) {
          final isCorrect = i < correct;
          return Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Container(
              width: 16,
              height: 6,
              decoration: BoxDecoration(
                color: isCorrect ? AppTheme.success : const Color(0xFFE5E7EB),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          );
        }),
        const SizedBox(width: 6),
        Text(
          '$correct/$total correct',
          style: GoogleFonts.manrope(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }
}
