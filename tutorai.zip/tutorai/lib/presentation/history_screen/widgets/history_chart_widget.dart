import 'package:fl_chart/fl_chart.dart';

import '../../../core/app_export.dart';

class HistoryChartWidget extends StatefulWidget {
  const HistoryChartWidget({super.key});

  @override
  State<HistoryChartWidget> createState() => _HistoryChartWidgetState();
}

class _HistoryChartWidgetState extends State<HistoryChartWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _chartAnim;
  int? _touchedIndex;

  // Mock quiz score data over last 7 sessions
  // TODO: Replace with actual session data from local/cloud storage
  static final List<Map<String, dynamic>> _sessionMaps = [
    {'day': 'Apr 15', 'subject': 'Biology', 'score': 78.0},
    {'day': 'Apr 16', 'subject': 'History', 'score': 55.0},
    {'day': 'Apr 17', 'subject': 'Maths', 'score': 62.0},
    {'day': 'Apr 18', 'subject': 'Physics', 'score': 92.0},
    {'day': 'Apr 19', 'subject': 'Maths', 'score': 55.0},
    {'day': 'Apr 20', 'subject': 'History', 'score': 64.0},
    {'day': 'Apr 21', 'subject': 'Biology', 'score': 88.0},
  ];

  late List<_SessionData> _sessions;

  static _SessionData _fromMap(Map<String, dynamic> map) {
    return _SessionData(
      day: map['day'] as String,
      subject: map['subject'] as String,
      score: map['score'] as double,
    );
  }

  @override
  void initState() {
    super.initState();
    _sessions = _sessionMaps.map(_fromMap).toList();
    _animController = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    );
    _chartAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
    );
    _animController.forward();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: theme.colorScheme.outline.withAlpha(102),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Score Trend', style: theme.textTheme.titleSmall),
                  Text('Last 7 sessions', style: theme.textTheme.labelSmall),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.primaryContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Avg: 70%',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.primary,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: isTablet ? 200 : 160,
            child: AnimatedBuilder(
              animation: _chartAnim,
              builder: (context, _) {
                return LineChart(_buildChartData(context));
              },
            ),
          ),
          const SizedBox(height: 12),
          _ChartLegend(sessions: _sessions, touchedIndex: _touchedIndex),
        ],
      ),
    );
  }

  LineChartData _buildChartData(BuildContext context) {
    final primary = AppTheme.primary;
    final spots = _sessions.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value.score * _chartAnim.value);
    }).toList();

    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawVerticalLine: false,
        horizontalInterval: 25,
        getDrawingHorizontalLine: (_) => FlLine(
          color: const Color(0xFFF3F4F6),
          strokeWidth: 1,
          dashArray: [4, 4],
        ),
      ),
      titlesData: FlTitlesData(
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            interval: 25,
            reservedSize: 32,
            getTitlesWidget: (val, _) => Text(
              '${val.toInt()}',
              style: GoogleFonts.manrope(
                fontSize: 10,
                color: AppTheme.textSecondary,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
          ),
        ),
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 28,
            getTitlesWidget: (val, _) {
              final idx = val.toInt();
              if (idx < 0 || idx >= _sessions.length) {
                return const SizedBox();
              }
              final day = _sessions[idx].day.split(' ')[1];
              return Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  day,
                  style: GoogleFonts.manrope(
                    fontSize: 10,
                    color: _touchedIndex == idx
                        ? AppTheme.primary
                        : AppTheme.textSecondary,
                    fontWeight: _touchedIndex == idx
                        ? FontWeight.w700
                        : FontWeight.w400,
                  ),
                ),
              );
            },
          ),
        ),
        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        rightTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
      ),
      borderData: FlBorderData(show: false),
      minX: 0,
      maxX: (_sessions.length - 1).toDouble(),
      minY: 0,
      maxY: 100,
      lineTouchData: LineTouchData(
        touchCallback: (event, response) {
          if (event is FlTapUpEvent || event is FlPanEndEvent) {
            setState(() => _touchedIndex = null);
          } else if (response?.lineBarSpots != null) {
            setState(
              () => _touchedIndex = response!.lineBarSpots!.first.x.toInt(),
            );
          }
        },
        touchTooltipData: LineTouchTooltipData(
          tooltipBgColor: AppTheme.textPrimary,
          tooltipRoundedRadius: 10,
          tooltipPadding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 6,
          ),
          getTooltipItems: (spots) {
            return spots.map((spot) {
              final idx = spot.x.toInt();
              final session = idx < _sessions.length ? _sessions[idx] : null;
              return LineTooltipItem(
                '${spot.y.toInt()}%\n',
                GoogleFonts.manrope(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
                children: [
                  TextSpan(
                    text: session?.subject ?? '',
                    style: GoogleFonts.manrope(
                      fontSize: 10,
                      fontWeight: FontWeight.w400,
                      color: Colors.white.withAlpha(179),
                    ),
                  ),
                ],
              );
            }).toList();
          },
        ),
      ),
      lineBarsData: [
        LineChartBarData(
          spots: spots,
          isCurved: true,
          curveSmoothness: 0.3,
          color: primary,
          barWidth: 2.5,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: true,
            getDotPainter: (spot, _, __, idx) {
              final score = spot.y;
              Color dotColor;
              if (score >= 80) {
                dotColor = AppTheme.success;
              } else if (score >= 60) {
                dotColor = AppTheme.warning;
              } else {
                dotColor = AppTheme.errorColor;
              }
              final isSelected = _touchedIndex == idx;
              return FlDotCirclePainter(
                radius: isSelected ? 6 : 4,
                color: dotColor,
                strokeWidth: 2,
                strokeColor: Colors.white,
              );
            },
          ),
          belowBarData: BarAreaData(
            show: true,
            gradient: LinearGradient(
              colors: [primary.withAlpha(38), primary.withAlpha(0)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ],
    );
  }
}

class _ChartLegend extends StatelessWidget {
  final List<_SessionData> sessions;
  final int? touchedIndex;

  const _ChartLegend({required this.sessions, required this.touchedIndex});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _LegendDot(color: AppTheme.success, label: '≥ 80%'),
        const SizedBox(width: 16),
        _LegendDot(color: AppTheme.warning, label: '60–79%'),
        const SizedBox(width: 16),
        _LegendDot(color: AppTheme.errorColor, label: '< 60%'),
      ],
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  const _LegendDot({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 5),
        Text(
          label,
          style: GoogleFonts.manrope(
            fontSize: 10,
            fontWeight: FontWeight.w500,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }
}

class _SessionData {
  final String day;
  final String subject;
  final double score;

  const _SessionData({
    required this.day,
    required this.subject,
    required this.score,
  });
}
