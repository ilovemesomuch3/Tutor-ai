
import '../../../core/app_export.dart';

class _LessonItem {
  final String title;
  final String subject;
  final int score;
  final String date;
  final LessonStatus status;
  final String emoji;

  const _LessonItem({
    required this.title,
    required this.subject,
    required this.score,
    required this.date,
    required this.status,
    required this.emoji,
  });
}

class HomeRecentLessonsWidget extends StatefulWidget {
  const HomeRecentLessonsWidget({super.key});

  @override
  State<HomeRecentLessonsWidget> createState() =>
      _HomeRecentLessonsWidgetState();
}

class _HomeRecentLessonsWidgetState extends State<HomeRecentLessonsWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _staggerController;
  final List<Animation<double>> _itemAnimations = [];

  static final List<Map<String, dynamic>> _lessonMaps = [
    {
      'title': 'Photosynthesis & Cellular Respiration',
      'subject': 'Biology',
      'score': 88,
      'date': 'Apr 21',
      'status': 'completed',
      'emoji': '🌱',
    },
    {
      'title': 'World War II — Causes & Effects',
      'subject': 'History',
      'score': 64,
      'date': 'Apr 20',
      'status': 'reviewing',
      'emoji': '📜',
    },
    {
      'title': 'Quadratic Equations',
      'subject': 'Mathematics',
      'score': 55,
      'date': 'Apr 19',
      'status': 'reviewing',
      'emoji': '📐',
    },
    {
      'title': 'Newton\'s Laws of Motion',
      'subject': 'Physics',
      'score': 92,
      'date': 'Apr 18',
      'status': 'completed',
      'emoji': '⚡',
    },
  ];

  late List<_LessonItem> _lessons;

  static LessonStatus _statusFromString(String s) {
    switch (s) {
      case 'completed':
        return LessonStatus.completed;
      case 'inProgress':
        return LessonStatus.inProgress;
      case 'reviewing':
        return LessonStatus.reviewing;
      default:
        return LessonStatus.notStarted;
    }
  }

  static _LessonItem _fromMap(Map<String, dynamic> map) {
    return _LessonItem(
      title: map['title'] as String,
      subject: map['subject'] as String,
      score: map['score'] as int,
      date: map['date'] as String,
      status: _statusFromString(map['status'] as String),
      emoji: map['emoji'] as String,
    );
  }

  @override
  void initState() {
    super.initState();
    _lessons = _lessonMaps.map(_fromMap).toList();

    _staggerController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    for (int i = 0; i < _lessons.length; i++) {
      final start = (i * 0.15).clamp(0.0, 1.0);
      final end = (start + 0.5).clamp(0.0, 1.0);
      _itemAnimations.add(
        Tween<double>(begin: 0, end: 1).animate(
          CurvedAnimation(
            parent: _staggerController,
            curve: Interval(start, end, curve: Curves.easeOutCubic),
          ),
        ),
      );
    }
    _staggerController.forward();
  }

  @override
  void dispose() {
    _staggerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Recent Lessons', style: theme.textTheme.titleMedium),
              TextButton(
                onPressed: () {},
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.primary,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  'See all',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primary,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        ...List.generate(_lessons.length, (index) {
          return AnimatedBuilder(
            animation: _itemAnimations[index],
            builder: (context, child) {
              return Transform.translate(
                offset: Offset(0, 20 * (1 - _itemAnimations[index].value)),
                child: Opacity(
                  opacity: _itemAnimations[index].value,
                  child: child,
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
              child: _LessonListItem(lesson: _lessons[index]),
            ),
          );
        }),
      ],
    );
  }
}

class _LessonListItem extends StatelessWidget {
  final _LessonItem lesson;

  const _LessonListItem({required this.lesson});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(16),
      splashColor: AppTheme.primaryMuted,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: theme.colorScheme.outline.withAlpha(102),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppTheme.primaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(lesson.emoji, style: const TextStyle(fontSize: 20)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    lesson.title,
                    style: theme.textTheme.titleSmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceVariantColor,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          lesson.subject,
                          style: GoogleFonts.manrope(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(lesson.date, style: theme.textTheme.labelSmall),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                ScoreBadgeWidget(score: lesson.score),
                const SizedBox(height: 6),
                StatusBadgeWidget(status: lesson.status),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
