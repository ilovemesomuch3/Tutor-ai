import '../../core/app_export.dart';
import './widgets/learn_dialogue_tab_widget.dart';
import './widgets/learn_input_widget.dart';
import './widgets/learn_questions_tab_widget.dart';
import './widgets/learn_summary_tab_widget.dart';

// TODO: Replace with Riverpod/Bloc for production state management
class LearnScreen extends StatefulWidget {
  const LearnScreen({super.key});

  @override
  State<LearnScreen> createState() => _LearnScreenState();
}

enum LearnPhase { input, processing, results }

class _LearnScreenState extends State<LearnScreen>
    with TickerProviderStateMixin {
  int _currentNavIndex = 1;
  LearnPhase _phase = LearnPhase.input;
  late TabController _tabController;

  // Mock AI-generated content
  // TODO: Replace with actual AI API call
  late LessonContent _lessonContent;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _lessonContent = LessonContent.mock();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _onNavTap(int index) {
    if (index == _currentNavIndex) return;
    setState(() => _currentNavIndex = index);
    switch (index) {
      case 0:
        Navigator.pushNamedAndRemoveUntil(
          context,
          AppRoutes.homeScreen,
          (r) => false,
        );
        break;
      case 1:
        break;
      case 2:
        Navigator.pushNamedAndRemoveUntil(
          context,
          AppRoutes.historyScreen,
          (r) => false,
        );
        break;
    }
  }

  void _onGenerateTapped(String lessonText) {
    if (lessonText.trim().isEmpty) return;
    setState(() => _phase = LearnPhase.processing);

    // TODO: Replace with actual AI API call using the lesson prompt template
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) {
        setState(() => _phase = LearnPhase.results);
      }
    });
  }

  void _onReset() {
    setState(() {
      _phase = LearnPhase.input;
      _tabController.index = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      bottomNavigationBar: isTablet
          ? null
          : AppNavigation(
              currentIndex: _currentNavIndex,
              onDestinationSelected: _onNavTap,
            ),
      body: SafeArea(
        child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return Column(
      children: [
        const SizedBox(height: 8),
        FloatingAppBarWidget(
          title: 'Learn',
          actions: _phase == LearnPhase.results
              ? [
                  IconButton(
                    icon: const Icon(
                      Icons.refresh_rounded,
                      color: AppTheme.textPrimary,
                      size: 20,
                    ),
                    onPressed: _onReset,
                    tooltip: 'New Lesson',
                  ),
                ]
              : [],
        ),
        const SizedBox(height: 8),
        Expanded(child: _buildContent(isTablet: false)),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      children: [
        AppNavigation(
          currentIndex: _currentNavIndex,
          onDestinationSelected: _onNavTap,
        ),
        const VerticalDivider(width: 1),
        Expanded(
          child: Column(
            children: [
              const SizedBox(height: 8),
              FloatingAppBarWidget(
                title: 'Learn',
                actions: _phase == LearnPhase.results
                    ? [
                        IconButton(
                          icon: const Icon(
                            Icons.refresh_rounded,
                            color: AppTheme.textPrimary,
                            size: 20,
                          ),
                          onPressed: _onReset,
                        ),
                      ]
                    : [],
              ),
              const SizedBox(height: 8),
              Expanded(child: _buildContent(isTablet: true)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildContent({required bool isTablet}) {
    if (_phase == LearnPhase.input) {
      return LearnInputWidget(onGenerate: _onGenerateTapped);
    }
    if (_phase == LearnPhase.processing) {
      return _ProcessingWidget();
    }
    // Results phase
    if (isTablet) {
      return _buildTabletResults();
    }
    return _buildPhoneResults();
  }

  Widget _buildPhoneResults() {
    return Column(
      children: [
        _ResultsTabBar(tabController: _tabController),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              LearnSummaryTabWidget(content: _lessonContent),
              LearnQuestionsTabWidget(content: _lessonContent),
              LearnDialogueTabWidget(content: _lessonContent),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTabletResults() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 5,
          child: Column(
            children: [
              _ResultsTabBar(tabController: _tabController),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    LearnSummaryTabWidget(content: _lessonContent),
                    LearnQuestionsTabWidget(content: _lessonContent),
                    LearnDialogueTabWidget(content: _lessonContent),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(width: 1, color: const Color(0xFFE9E8F8)),
        Expanded(flex: 3, child: _TabletSidebar(content: _lessonContent)),
      ],
    );
  }
}

class _ResultsTabBar extends StatelessWidget {
  final TabController tabController;
  const _ResultsTabBar({required this.tabController});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariantColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TabBar(
        controller: tabController,
        indicator: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: AppTheme.primary.withAlpha(20),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: AppTheme.primary,
        unselectedLabelColor: AppTheme.textSecondary,
        labelStyle: GoogleFonts.manrope(
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
        unselectedLabelStyle: GoogleFonts.manrope(
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
        tabs: const [
          Tab(text: 'Summary'),
          Tab(text: 'Questions'),
          Tab(text: 'Dialogue'),
        ],
      ),
    );
  }
}

class _ProcessingWidget extends StatefulWidget {
  @override
  State<_ProcessingWidget> createState() => _ProcessingWidgetState();
}

class _ProcessingWidgetState extends State<_ProcessingWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulse;

  final List<String> _steps = [
    'Reading your lesson...',
    'Generating summary...',
    'Creating questions...',
    'Writing dialogue...',
  ];
  int _currentStep = 0;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _stepTimer();
  }

  void _stepTimer() async {
    for (int i = 1; i < _steps.length; i++) {
      await Future.delayed(const Duration(milliseconds: 450));
      if (mounted) setState(() => _currentStep = i);
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ScaleTransition(
              scale: _pulse,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: AppTheme.primaryContainer,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(
                  Icons.auto_awesome_rounded,
                  color: AppTheme.primary,
                  size: 36,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text('TutorAI is thinking...', style: theme.textTheme.titleMedium),
            const SizedBox(height: 24),
            ...List.generate(_steps.length, (i) {
              final isDone = i < _currentStep;
              final isCurrent = i == _currentStep;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: isDone
                      ? AppTheme.successContainer
                      : isCurrent
                      ? AppTheme.primaryContainer
                      : const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: isDone
                        ? AppTheme.success.withAlpha(77)
                        : isCurrent
                        ? AppTheme.primary.withAlpha(77)
                        : Colors.transparent,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      isDone
                          ? Icons.check_circle_rounded
                          : isCurrent
                          ? Icons.radio_button_on_rounded
                          : Icons.radio_button_off_rounded,
                      size: 18,
                      color: isDone
                          ? AppTheme.success
                          : isCurrent
                          ? AppTheme.primary
                          : AppTheme.textSecondary,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _steps[i],
                      style: GoogleFonts.manrope(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: isDone
                            ? AppTheme.success
                            : isCurrent
                            ? AppTheme.primary
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

class _TabletSidebar extends StatelessWidget {
  final LessonContent content;
  const _TabletSidebar({required this.content});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Key Points', style: theme.textTheme.titleMedium),
          const SizedBox(height: 12),
          ...content.keyPoints.map(
            (kp) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    margin: const EdgeInsets.only(top: 6, right: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.primary,
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                  Expanded(child: Text(kp, style: theme.textTheme.bodySmall)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.emoji_events_rounded,
                  color: AppTheme.primary,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Complete all questions to earn your score!',
                    style: GoogleFonts.manrope(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Data model
class LessonContent {
  final String lessonTitle;
  final List<String> summaryPoints;
  final List<String> keyPoints;
  final List<LessonQuestion> questions;
  final List<DialogueLine> dialogue;

  const LessonContent({
    required this.lessonTitle,
    required this.summaryPoints,
    required this.keyPoints,
    required this.questions,
    required this.dialogue,
  });

  factory LessonContent.mock() {
    return LessonContent(
      lessonTitle: 'Photosynthesis',
      summaryPoints: [
        'Photosynthesis is how plants make their own food using sunlight.',
        'It happens mainly in the leaves, inside structures called chloroplasts.',
        'Plants take in carbon dioxide from the air and water from the soil.',
        'Sunlight gives the energy needed to turn these into glucose and oxygen.',
        'The oxygen is released into the air, which is what we breathe.',
      ],
      keyPoints: [
        'Chloroplasts contain chlorophyll — the green pigment that captures light.',
        'The equation: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂',
        'Light reactions happen in the thylakoid membrane.',
        'The Calvin cycle happens in the stroma of the chloroplast.',
        'Glucose is used for energy and building plant material.',
      ],
      questions: [
        LessonQuestion(
          id: 'q1',
          type: QuestionType.mcq,
          question: 'Where does photosynthesis mainly take place in a plant?',
          options: ['Roots', 'Stem', 'Leaves', 'Flowers'],
          correctAnswer: 'Leaves',
          explanation:
              'Leaves contain the most chloroplasts, making them the primary site of photosynthesis.',
        ),
        LessonQuestion(
          id: 'q2',
          type: QuestionType.mcq,
          question:
              'Which molecule captures light energy during photosynthesis?',
          options: ['Glucose', 'Chlorophyll', 'Carbon dioxide', 'Oxygen'],
          correctAnswer: 'Chlorophyll',
          explanation:
              'Chlorophyll is the green pigment in chloroplasts that absorbs light energy.',
        ),
        LessonQuestion(
          id: 'q3',
          type: QuestionType.trueFalse,
          question:
              'Plants release carbon dioxide as a by-product of photosynthesis.',
          correctAnswer: 'False',
          explanation:
              'Plants release oxygen, not carbon dioxide, as a by-product. CO₂ is consumed.',
        ),
        LessonQuestion(
          id: 'q4',
          type: QuestionType.trueFalse,
          question: 'Photosynthesis requires light energy to occur.',
          correctAnswer: 'True',
          explanation:
              'Light energy is essential to drive the chemical reactions of photosynthesis.',
        ),
        LessonQuestion(
          id: 'q5',
          type: QuestionType.shortAnswer,
          question:
              'In your own words, explain why photosynthesis is important for life on Earth.',
          correctAnswer:
              'Photosynthesis produces oxygen for breathing and glucose for energy, forming the base of most food chains.',
          explanation:
              'A complete answer should mention oxygen production and its role in food chains or energy supply.',
        ),
      ],
      dialogue: [
        DialogueLine(
          speaker: 'Maya',
          text: 'Hey, do you understand what photosynthesis actually is?',
          isLeft: true,
        ),
        DialogueLine(
          speaker: 'Kwame',
          text: 'Kind of — it\'s how plants make food, right? Using sunlight?',
          isLeft: false,
        ),
        DialogueLine(
          speaker: 'Maya',
          text:
              'Exactly! They also need water from the soil and CO₂ from the air.',
          isLeft: true,
        ),
        DialogueLine(
          speaker: 'Kwame',
          text:
              'Oh, so they\'re basically cooking with sunlight as the heat source!',
          isLeft: false,
        ),
        DialogueLine(
          speaker: 'Maya',
          text:
              'Ha! That\'s a great way to put it. And the "food" they make is glucose.',
          isLeft: true,
        ),
        DialogueLine(
          speaker: 'Kwame',
          text:
              'And they release oxygen in the process — which is what we breathe!',
          isLeft: false,
        ),
        DialogueLine(
          speaker: 'Maya',
          text: 'Exactly. So every breath you take? Thank a plant! 🌿',
          isLeft: true,
        ),
        DialogueLine(
          speaker: 'Kwame',
          text:
              'That\'s actually really cool. Plants are doing us a huge favour.',
          isLeft: false,
        ),
      ],
    );
  }
}

enum QuestionType { mcq, trueFalse, shortAnswer }

class LessonQuestion {
  final String id;
  final QuestionType type;
  final String question;
  final List<String>? options;
  final String correctAnswer;
  final String explanation;

  const LessonQuestion({
    required this.id,
    required this.type,
    required this.question,
    this.options,
    required this.correctAnswer,
    required this.explanation,
  });
}

class DialogueLine {
  final String speaker;
  final String text;
  final bool isLeft;

  const DialogueLine({
    required this.speaker,
    required this.text,
    required this.isLeft,
  });
}