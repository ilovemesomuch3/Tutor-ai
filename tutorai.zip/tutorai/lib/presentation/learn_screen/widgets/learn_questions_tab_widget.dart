
import '../../../core/app_export.dart';
import '../learn_screen.dart';

// TODO: Replace with Riverpod/Bloc for production state management
class LearnQuestionsTabWidget extends StatefulWidget {
  final LessonContent content;
  const LearnQuestionsTabWidget({super.key, required this.content});

  @override
  State<LearnQuestionsTabWidget> createState() =>
      _LearnQuestionsTabWidgetState();
}

class _LearnQuestionsTabWidgetState extends State<LearnQuestionsTabWidget> {
  final Map<String, dynamic> _answers = {};
  final Map<String, bool> _submitted = {};
  bool _allSubmitted = false;
  int _score = 0;

  void _submitAnswer(LessonQuestion question, dynamic answer) {
    setState(() {
      _answers[question.id] = answer;
      _submitted[question.id] = true;

      final isCorrect =
          answer.toString().toLowerCase() ==
          question.correctAnswer.toLowerCase();
      if (isCorrect) _score++;

      _allSubmitted = widget.content.questions.every(
        (q) => _submitted[q.id] == true,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _QuizHeader(
          total: widget.content.questions.length,
          answered: _submitted.length,
          score: _allSubmitted ? _score : null,
        ),
        const SizedBox(height: 16),
        ...widget.content.questions.asMap().entries.map((entry) {
          final i = entry.key;
          final q = entry.value;
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: _QuestionCard(
              question: q,
              questionNumber: i + 1,
              selectedAnswer: _answers[q.id],
              isSubmitted: _submitted[q.id] ?? false,
              onSubmit: (answer) => _submitAnswer(q, answer),
            ),
          );
        }),
        if (_allSubmitted) ...[
          const SizedBox(height: 8),
          _ScoreSummaryCard(
            score: _score,
            total: widget.content.questions.length,
          ),
        ],
        const SizedBox(height: 80),
      ],
    );
  }
}

class _QuizHeader extends StatelessWidget {
  final int total;
  final int answered;
  final int? score;

  const _QuizHeader({required this.total, required this.answered, this.score});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress = total > 0 ? answered / total : 0.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '$answered of $total answered',
              style: theme.textTheme.labelMedium,
            ),
            if (score != null)
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: score! >= 4
                      ? AppTheme.successContainer
                      : score! >= 3
                      ? AppTheme.warningContainer
                      : AppTheme.errorContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Score: $score/$total',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: score! >= 4
                        ? AppTheme.success
                        : score! >= 3
                        ? AppTheme.warning
                        : AppTheme.errorColor,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: Theme.of(
              context,
            ).colorScheme.surfaceContainerHighest,
            valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primary),
            minHeight: 5,
          ),
        ),
      ],
    );
  }
}

class _QuestionCard extends StatefulWidget {
  final LessonQuestion question;
  final int questionNumber;
  final dynamic selectedAnswer;
  final bool isSubmitted;
  final ValueChanged<dynamic> onSubmit;

  const _QuestionCard({
    required this.question,
    required this.questionNumber,
    required this.selectedAnswer,
    required this.isSubmitted,
    required this.onSubmit,
  });

  @override
  State<_QuestionCard> createState() => _QuestionCardState();
}

class _QuestionCardState extends State<_QuestionCard>
    with SingleTickerProviderStateMixin {
  dynamic _localAnswer;
  late AnimationController _feedbackController;
  late Animation<double> _feedbackAnim;

  @override
  void initState() {
    super.initState();
    _localAnswer = widget.selectedAnswer;
    _feedbackController = AnimationController(
      duration: const Duration(milliseconds: 350),
      vsync: this,
    );
    _feedbackAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _feedbackController, curve: Curves.easeOutCubic),
    );
    if (widget.isSubmitted) _feedbackController.value = 1;
  }

  @override
  void didUpdateWidget(_QuestionCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isSubmitted && !oldWidget.isSubmitted) {
      _feedbackController.forward();
    }
  }

  @override
  void dispose() {
    _feedbackController.dispose();
    super.dispose();
  }

  bool get _isCorrect =>
      _localAnswer?.toString().toLowerCase() ==
      widget.question.correctAnswer.toLowerCase();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: widget.isSubmitted
              ? (_isCorrect
                    ? AppTheme.success.withAlpha(128)
                    : AppTheme.errorColor.withAlpha(128))
              : theme.colorScheme.outline.withAlpha(102),
          width: 1.5,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _QuestionTypeBadge(type: widget.question.type),
                const SizedBox(width: 8),
                Text(
                  'Q${widget.questionNumber}',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              widget.question.question,
              style: theme.textTheme.titleSmall?.copyWith(height: 1.5),
            ),
            const SizedBox(height: 16),
            _buildAnswerUI(),
            if (widget.isSubmitted) ...[
              const SizedBox(height: 12),
              AnimatedBuilder(
                animation: _feedbackAnim,
                builder: (context, child) {
                  return Transform.translate(
                    offset: Offset(0, 12 * (1 - _feedbackAnim.value)),
                    child: Opacity(opacity: _feedbackAnim.value, child: child),
                  );
                },
                child: _FeedbackCard(
                  isCorrect: _isCorrect,
                  explanation: widget.question.explanation,
                  correctAnswer: widget.question.correctAnswer,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAnswerUI() {
    switch (widget.question.type) {
      case QuestionType.mcq:
        return _MCQOptions(
          options: widget.question.options!,
          selected: _localAnswer,
          isSubmitted: widget.isSubmitted,
          correctAnswer: widget.question.correctAnswer,
          onSelect: (val) {
            if (widget.isSubmitted) return;
            setState(() => _localAnswer = val);
          },
          onSubmit: () {
            if (_localAnswer != null) widget.onSubmit(_localAnswer);
          },
        );
      case QuestionType.trueFalse:
        return _TrueFalseOptions(
          selected: _localAnswer,
          isSubmitted: widget.isSubmitted,
          correctAnswer: widget.question.correctAnswer,
          onSelect: (val) {
            if (widget.isSubmitted) return;
            setState(() => _localAnswer = val);
            widget.onSubmit(val);
          },
        );
      case QuestionType.shortAnswer:
        return _ShortAnswerField(
          isSubmitted: widget.isSubmitted,
          onSubmit: (val) {
            setState(() => _localAnswer = val);
            widget.onSubmit(val);
          },
        );
    }
  }
}

class _QuestionTypeBadge extends StatelessWidget {
  final QuestionType type;
  const _QuestionTypeBadge({required this.type});

  @override
  Widget build(BuildContext context) {
    String label;
    Color bg;
    Color fg;
    switch (type) {
      case QuestionType.mcq:
        label = 'Multiple Choice';
        bg = AppTheme.primaryContainer;
        fg = AppTheme.primary;
        break;
      case QuestionType.trueFalse:
        label = 'True / False';
        bg = AppTheme.secondaryContainer;
        fg = AppTheme.warning;
        break;
      case QuestionType.shortAnswer:
        label = 'Short Answer';
        bg = const Color(0xFFEDE9FE);
        fg = const Color(0xFF7C3AED);
        break;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: GoogleFonts.manrope(
          fontSize: 10,
          fontWeight: FontWeight.w700,
          color: fg,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

class _MCQOptions extends StatelessWidget {
  final List<String> options;
  final dynamic selected;
  final bool isSubmitted;
  final String correctAnswer;
  final ValueChanged<String> onSelect;
  final VoidCallback onSubmit;

  const _MCQOptions({
    required this.options,
    required this.selected,
    required this.isSubmitted,
    required this.correctAnswer,
    required this.onSelect,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ...options.map((opt) {
          final isSelected = selected == opt;
          final isCorrect = opt == correctAnswer;
          Color bg = Colors.white;
          Color border = const Color(0xFFE5E7EB);
          Color textColor = AppTheme.textPrimary;
          if (isSubmitted) {
            if (isCorrect) {
              bg = AppTheme.successContainer;
              border = AppTheme.success;
              textColor = AppTheme.success;
            } else if (isSelected && !isCorrect) {
              bg = AppTheme.errorContainer;
              border = AppTheme.errorColor;
              textColor = AppTheme.errorColor;
            }
          } else if (isSelected) {
            bg = AppTheme.primaryContainer;
            border = AppTheme.primary;
            textColor = AppTheme.primary;
          }

          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: GestureDetector(
              onTap: () => onSelect(opt),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: bg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: border, width: 1.5),
                ),
                child: Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isSelected || (isSubmitted && isCorrect)
                            ? (isSubmitted
                                  ? (isCorrect
                                        ? AppTheme.success
                                        : AppTheme.errorColor)
                                  : AppTheme.primary)
                            : Colors.white,
                        border: Border.all(color: border, width: 1.5),
                      ),
                      child: (isSelected || (isSubmitted && isCorrect))
                          ? const Icon(
                              Icons.check_rounded,
                              size: 12,
                              color: Colors.white,
                            )
                          : null,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        opt,
                        style: GoogleFonts.manrope(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: textColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
        if (!isSubmitted && selected != null) ...[
          const SizedBox(height: 4),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: FilledButton(
              onPressed: onSubmit,
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Submit Answer',
                style: GoogleFonts.manrope(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}

class _TrueFalseOptions extends StatelessWidget {
  final dynamic selected;
  final bool isSubmitted;
  final String correctAnswer;
  final ValueChanged<String> onSelect;

  const _TrueFalseOptions({
    required this.selected,
    required this.isSubmitted,
    required this.correctAnswer,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: ['True', 'False'].map((opt) {
        final isSelected = selected == opt;
        final isCorrect = opt == correctAnswer;
        Color bg, border, textColor;

        if (isSubmitted) {
          if (isCorrect) {
            bg = AppTheme.successContainer;
            border = AppTheme.success;
            textColor = AppTheme.success;
          } else if (isSelected && !isCorrect) {
            bg = AppTheme.errorContainer;
            border = AppTheme.errorColor;
            textColor = AppTheme.errorColor;
          } else {
            bg = Colors.white;
            border = const Color(0xFFE5E7EB);
            textColor = AppTheme.textSecondary;
          }
        } else if (isSelected) {
          bg = AppTheme.primaryContainer;
          border = AppTheme.primary;
          textColor = AppTheme.primary;
        } else {
          bg = Colors.white;
          border = const Color(0xFFE5E7EB);
          textColor = AppTheme.textPrimary;
        }

        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: opt == 'True' ? 8 : 0),
            child: GestureDetector(
              onTap: () => onSelect(opt),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: bg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: border, width: 1.5),
                ),
                child: Center(
                  child: Text(
                    opt == 'True' ? '✓ True' : '✗ False',
                    style: GoogleFonts.manrope(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: textColor,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _ShortAnswerField extends StatefulWidget {
  final bool isSubmitted;
  final ValueChanged<String> onSubmit;

  const _ShortAnswerField({required this.isSubmitted, required this.onSubmit});

  @override
  State<_ShortAnswerField> createState() => _ShortAnswerFieldState();
}

class _ShortAnswerFieldState extends State<_ShortAnswerField> {
  final TextEditingController _ctrl = TextEditingController();
  bool _hasText = false;

  @override
  void initState() {
    super.initState();
    _ctrl.addListener(() {
      final h = _ctrl.text.trim().isNotEmpty;
      if (h != _hasText) setState(() => _hasText = h);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            color: widget.isSubmitted ? const Color(0xFFF9FAFB) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE5E7EB), width: 1),
          ),
          child: TextField(
            controller: _ctrl,
            enabled: !widget.isSubmitted,
            maxLines: 4,
            minLines: 3,
            style: GoogleFonts.manrope(
              fontSize: 13,
              fontWeight: FontWeight.w400,
              color: AppTheme.textPrimary,
              height: 1.5,
            ),
            decoration: InputDecoration(
              hintText: 'Write your answer here...',
              hintStyle: GoogleFonts.manrope(
                fontSize: 13,
                color: AppTheme.textSecondary.withAlpha(128),
              ),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              contentPadding: const EdgeInsets.all(14),
            ),
          ),
        ),
        if (!widget.isSubmitted) ...[
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 44,
            child: FilledButton(
              onPressed: _hasText ? () => widget.onSubmit(_ctrl.text) : null,
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.primary,
                disabledBackgroundColor: AppTheme.primary.withAlpha(77),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Submit Answer',
                style: GoogleFonts.manrope(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}

class _FeedbackCard extends StatelessWidget {
  final bool isCorrect;
  final String explanation;
  final String correctAnswer;

  const _FeedbackCard({
    required this.isCorrect,
    required this.explanation,
    required this.correctAnswer,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isCorrect ? AppTheme.successContainer : AppTheme.errorContainer,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isCorrect
              ? AppTheme.success.withAlpha(102)
              : AppTheme.errorColor.withAlpha(102),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isCorrect ? Icons.check_circle_rounded : Icons.info_rounded,
                size: 16,
                color: isCorrect ? AppTheme.success : AppTheme.errorColor,
              ),
              const SizedBox(width: 6),
              Text(
                isCorrect ? 'Correct! Well done 🎉' : 'Not quite right',
                style: GoogleFonts.manrope(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: isCorrect ? AppTheme.success : AppTheme.errorColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            explanation,
            style: GoogleFonts.manrope(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: isCorrect ? AppTheme.success : AppTheme.errorColor,
              height: 1.5,
            ),
          ),
          if (!isCorrect) ...[
            const SizedBox(height: 6),
            Text(
              'Correct answer: $correctAnswer',
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.errorColor,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ScoreSummaryCard extends StatelessWidget {
  final int score;
  final int total;

  const _ScoreSummaryCard({required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    final pct = (score / total * 100).round();
    final isGood = pct >= 80;
    final isMid = pct >= 60;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isGood
              ? [AppTheme.success, const Color(0xFF34D399)]
              : isMid
              ? [AppTheme.warning, const Color(0xFFFBBF24)]
              : [AppTheme.errorColor, const Color(0xFFF87171)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isGood
                      ? 'Excellent work! 🎉'
                      : isMid
                      ? 'Good effort! Keep going 💪'
                      : 'Keep practising! You\'ll get there 📚',
                  style: GoogleFonts.manrope(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'You answered $score out of $total correctly.',
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    color: Colors.white.withAlpha(217),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Column(
            children: [
              Text(
                '$pct%',
                style: GoogleFonts.manrope(
                  fontSize: 36,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  fontFeatures: const [FontFeature.tabularFigures()],
                  letterSpacing: -1,
                ),
              ),
              Text(
                'Score',
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  color: Colors.white.withAlpha(204),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
