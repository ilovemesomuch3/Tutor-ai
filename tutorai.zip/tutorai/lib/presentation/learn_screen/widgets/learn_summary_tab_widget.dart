
import '../../../core/app_export.dart';
import '../learn_screen.dart';

class LearnSummaryTabWidget extends StatefulWidget {
  final LessonContent content;
  const LearnSummaryTabWidget({super.key, required this.content});

  @override
  State<LearnSummaryTabWidget> createState() => _LearnSummaryTabWidgetState();
}

class _LearnSummaryTabWidgetState extends State<LearnSummaryTabWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  final List<Animation<double>> _animations = [];

  @override
  void initState() {
    super.initState();
    final total =
        widget.content.summaryPoints.length +
        widget.content.keyPoints.length +
        2;
    _animController = AnimationController(
      duration: Duration(milliseconds: 300 + total * 80),
      vsync: this,
    );

    for (int i = 0; i < total; i++) {
      final start = (i * 0.08).clamp(0.0, 0.9);
      final end = (start + 0.25).clamp(0.0, 1.0);
      _animations.add(
        Tween<double>(begin: 0, end: 1).animate(
          CurvedAnimation(
            parent: _animController,
            curve: Interval(start, end, curve: Curves.easeOutCubic),
          ),
        ),
      );
    }
    _animController.forward();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    int animIndex = 0;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        // Summary section
        _AnimatedSection(
          animation: _animations[animIndex++],
          child: _SectionHeader(
            icon: Icons.summarize_rounded,
            title: 'Summary',
            subtitle: '${widget.content.summaryPoints.length} key sentences',
          ),
        ),
        const SizedBox(height: 12),
        ...widget.content.summaryPoints.map((point) {
          final anim = _animations[animIndex++];
          return _AnimatedSection(
            animation: anim,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _SummaryPointCard(text: point),
            ),
          );
        }),
        const SizedBox(height: 20),
        _AnimatedSection(
          animation: _animations[animIndex++],
          child: _SectionHeader(
            icon: Icons.lightbulb_outline_rounded,
            title: 'Key Points',
            subtitle: '${widget.content.keyPoints.length} concepts to remember',
          ),
        ),
        const SizedBox(height: 12),
        ...widget.content.keyPoints.asMap().entries.map((entry) {
          final anim =
              _animations[animIndex < _animations.length
                  ? animIndex++
                  : _animations.length - 1];
          return _AnimatedSection(
            animation: anim,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _KeyPointRow(number: entry.key + 1, text: entry.value),
            ),
          );
        }),
        const SizedBox(height: 80),
      ],
    );
  }
}

class _AnimatedSection extends StatelessWidget {
  final Animation<double> animation;
  final Widget child;

  const _AnimatedSection({required this.animation, required this.child});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) {
        return Transform.translate(
          offset: Offset(0, 16 * (1 - animation.value)),
          child: Opacity(opacity: animation.value, child: child),
        );
      },
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _SectionHeader({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: AppTheme.primaryContainer,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: AppTheme.primary),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleSmall),
            Text(subtitle, style: theme.textTheme.labelSmall),
          ],
        ),
      ],
    );
  }
}

class _SummaryPointCard extends StatelessWidget {
  final String text;
  const _SummaryPointCard({required this.text});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: theme.colorScheme.outline.withAlpha(89),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 6,
            height: 6,
            margin: const EdgeInsets.only(top: 6, right: 10),
            decoration: BoxDecoration(
              color: AppTheme.primary,
              borderRadius: BorderRadius.circular(999),
            ),
          ),
          Expanded(
            child: Text(
              text,
              style: theme.textTheme.bodyMedium?.copyWith(height: 1.55),
            ),
          ),
        ],
      ),
    );
  }
}

class _KeyPointRow extends StatelessWidget {
  final int number;
  final String text;

  const _KeyPointRow({required this.number, required this.text});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: theme.colorScheme.outline.withAlpha(89),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: Text(
                '$number',
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.primary,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: theme.textTheme.bodySmall?.copyWith(
                color: AppTheme.textPrimary,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
