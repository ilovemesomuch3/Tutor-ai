
import '../../../core/app_export.dart';

class LearnInputWidget extends StatefulWidget {
  final ValueChanged<String> onGenerate;

  const LearnInputWidget({super.key, required this.onGenerate});

  @override
  State<LearnInputWidget> createState() => _LearnInputWidgetState();
}

class _LearnInputWidgetState extends State<LearnInputWidget> {
  final TextEditingController _controller = TextEditingController();
  bool _hasText = false;

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      final hasText = _controller.text.trim().isNotEmpty;
      if (hasText != _hasText) {
        setState(() => _hasText = hasText);
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          _WelcomeBanner(),
          const SizedBox(height: 24),
          Text('Paste your lesson text', style: theme.textTheme.titleSmall),
          const SizedBox(height: 4),
          Text(
            'TutorAI will generate a summary, key points, questions, and a dialogue.',
            style: theme.textTheme.bodySmall?.copyWith(height: 1.5),
          ),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _hasText
                    ? AppTheme.primary.withAlpha(102)
                    : theme.colorScheme.outline.withAlpha(102),
                width: 1.5,
              ),
            ),
            child: TextField(
              controller: _controller,
              maxLines: 12,
              minLines: 8,
              style: GoogleFonts.manrope(
                fontSize: 14,
                fontWeight: FontWeight.w400,
                color: AppTheme.textPrimary,
                height: 1.6,
              ),
              decoration: InputDecoration(
                hintText:
                    'Paste your lesson, chapter, or notes here...\n\nExample: "Photosynthesis is the process by which green plants convert sunlight into food..."',
                hintStyle: GoogleFonts.manrope(
                  fontSize: 13,
                  color: AppTheme.textSecondary.withAlpha(153),
                  height: 1.6,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding: const EdgeInsets.all(16),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: AnimatedOpacity(
              opacity: _hasText ? 1.0 : 0.4,
              duration: const Duration(milliseconds: 200),
              child: Text(
                '${_controller.text.split(' ').where((w) => w.isNotEmpty).length} words',
                style: theme.textTheme.labelSmall,
              ),
            ),
          ),
          const SizedBox(height: 20),
          _SubjectChips(),
          const SizedBox(height: 24),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: double.infinity,
            height: 52,
            child: FilledButton.icon(
              onPressed: _hasText
                  ? () => widget.onGenerate(_controller.text)
                  : null,
              icon: const Icon(Icons.auto_awesome_rounded, size: 18),
              label: Text(
                'Generate Learning Content',
                style: GoogleFonts.manrope(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.primary,
                disabledBackgroundColor: AppTheme.primary.withAlpha(77),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _ExampleLessons(
            onSelect: (text) {
              _controller.text = text;
              setState(() => _hasText = true);
            },
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _WelcomeBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primary.withAlpha(20),
            AppTheme.primary.withAlpha(8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primary.withAlpha(38), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.psychology_rounded,
              color: AppTheme.primary,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Ready to learn smarter?',
                  style: GoogleFonts.manrope(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.primary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Paste any lesson and let AI break it down for you.',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    color: AppTheme.primary.withAlpha(179),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SubjectChips extends StatefulWidget {
  @override
  State<_SubjectChips> createState() => _SubjectChipsState();
}

class _SubjectChipsState extends State<_SubjectChips> {
  final List<String> _subjects = [
    '📘 Biology',
    '📐 Maths',
    '📜 History',
    '⚗️ Chemistry',
    '🌍 Geography',
    '⚡ Physics',
  ];
  int _selected = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Subject (optional)',
          style: Theme.of(context).textTheme.labelMedium,
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: List.generate(_subjects.length, (i) {
              final isSelected = _selected == i;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: () => setState(() => _selected = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.primaryContainer
                          : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.primary.withAlpha(102)
                            : const Color(0xFFE5E7EB),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      _subjects[i],
                      style: GoogleFonts.manrope(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isSelected
                            ? AppTheme.primary
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ],
    );
  }
}

class _ExampleLessons extends StatelessWidget {
  final ValueChanged<String> onSelect;
  const _ExampleLessons({required this.onSelect});

  static const List<Map<String, String>> _examples = [
    {
      'label': '🌱 Photosynthesis',
      'text':
          'Photosynthesis is the process by which green plants, algae, and some bacteria convert light energy into chemical energy stored as glucose. This process occurs mainly in the leaves of plants, in organelles called chloroplasts, which contain a green pigment called chlorophyll. During photosynthesis, plants absorb carbon dioxide from the atmosphere through tiny pores called stomata, and water from the soil through their roots. Using sunlight as energy, they convert these raw materials into glucose (C6H12O6) and oxygen. The oxygen is released into the atmosphere as a by-product, while the glucose is used by the plant for energy and growth.',
    },
    {
      'label': '⚡ Newton\'s Laws',
      'text':
          'Newton\'s three laws of motion form the foundation of classical mechanics. The first law states that an object at rest stays at rest, and an object in motion stays in motion at the same speed and direction unless acted upon by an unbalanced force — this is also called the law of inertia. The second law states that the acceleration of an object depends on the net force acting on it and its mass: F = ma. The third law states that for every action, there is an equal and opposite reaction. These laws explain everyday phenomena such as why seatbelts are needed, how rockets are propelled, and why it is harder to push a heavy object than a light one.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Try an example', style: theme.textTheme.labelMedium),
        const SizedBox(height: 8),
        Row(
          children: _examples.map((e) {
            return Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: e == _examples.last ? 0 : 8),
                child: OutlinedButton(
                  onPressed: () => onSelect(e['text']!),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.primary,
                    side: BorderSide(color: AppTheme.primary.withAlpha(77)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      vertical: 10,
                      horizontal: 8,
                    ),
                    textStyle: GoogleFonts.manrope(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  child: Text(e['label']!),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
