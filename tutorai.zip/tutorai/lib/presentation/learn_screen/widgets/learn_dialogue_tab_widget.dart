
import '../../../core/app_export.dart';
import '../learn_screen.dart';

class LearnDialogueTabWidget extends StatefulWidget {
  final LessonContent content;
  const LearnDialogueTabWidget({super.key, required this.content});

  @override
  State<LearnDialogueTabWidget> createState() => _LearnDialogueTabWidgetState();
}

class _LearnDialogueTabWidgetState extends State<LearnDialogueTabWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _staggerController;
  final List<Animation<double>> _lineAnimations = [];

  @override
  void initState() {
    super.initState();
    _staggerController = AnimationController(
      duration: Duration(
        milliseconds: 400 + widget.content.dialogue.length * 120,
      ),
      vsync: this,
    );

    for (int i = 0; i < widget.content.dialogue.length; i++) {
      final start = (i * 0.1).clamp(0.0, 0.85);
      final end = (start + 0.3).clamp(0.0, 1.0);
      _lineAnimations.add(
        Tween<double>(begin: 0, end: 1).animate(
          CurvedAnimation(
            parent: _staggerController,
            curve: Interval(start, end, curve: Curves.easeOutCubic),
          ),
        ),
      );
    }
    _staggerController.forward();
  }

  @override
  void dispose() {
    _staggerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _DialogueHeader(),
        const SizedBox(height: 20),
        ...widget.content.dialogue.asMap().entries.map((entry) {
          final i = entry.key;
          final line = entry.value;
          return AnimatedBuilder(
            animation: _lineAnimations[i],
            builder: (context, child) {
              final anim = _lineAnimations[i].value;
              return Transform.translate(
                offset: Offset(
                  line.isLeft ? -20 * (1 - anim) : 20 * (1 - anim),
                  0,
                ),
                child: Opacity(opacity: anim, child: child),
              );
            },
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _DialogueBubble(line: line),
            ),
          );
        }),
        const SizedBox(height: 16),
        _DialogueTip(),
        const SizedBox(height: 80),
      ],
    );
  }
}

class _DialogueHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariantColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.primary.withAlpha(38), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.forum_rounded,
              color: AppTheme.primary,
              size: 18,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Student Dialogue',
                  style: GoogleFonts.manrope(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                Text(
                  'Two students explaining the lesson to each other',
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DialogueBubble extends StatelessWidget {
  final DialogueLine line;
  const _DialogueBubble({required this.line});

  @override
  Widget build(BuildContext context) {
    final isLeft = line.isLeft;
    final bubbleColor = isLeft
        ? AppTheme.primaryContainer
        : const Color(0xFFF0FDF4);
    final textColor = isLeft ? AppTheme.primary : AppTheme.success;
    final avatarBg = isLeft ? AppTheme.primary : AppTheme.success;
    final initial = line.speaker[0];

    return Row(
      mainAxisAlignment: isLeft
          ? MainAxisAlignment.start
          : MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        if (isLeft) ...[
          _Avatar(initial: initial, bg: avatarBg),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Column(
            crossAxisAlignment: isLeft
                ? CrossAxisAlignment.start
                : CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(
                  left: isLeft ? 4 : 0,
                  right: isLeft ? 0 : 4,
                  bottom: 4,
                ),
                child: Text(
                  line.speaker,
                  style: GoogleFonts.manrope(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: textColor,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: bubbleColor,
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(16),
                    topRight: const Radius.circular(16),
                    bottomLeft: Radius.circular(isLeft ? 4 : 16),
                    bottomRight: Radius.circular(isLeft ? 16 : 4),
                  ),
                  border: Border.all(color: textColor.withAlpha(51), width: 1),
                ),
                child: Text(
                  line.text,
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    color: AppTheme.textPrimary,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ),
        if (!isLeft) ...[
          const SizedBox(width: 8),
          _Avatar(initial: initial, bg: avatarBg),
        ],
      ],
    );
  }
}

class _Avatar extends StatelessWidget {
  final String initial;
  final Color bg;
  const _Avatar({required this.initial, required this.bg});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Center(
        child: Text(
          initial,
          style: GoogleFonts.manrope(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _DialogueTip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.secondaryContainer,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.secondary.withAlpha(77), width: 1),
      ),
      child: Row(
        children: [
          const Text('💡', style: TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'Try explaining the lesson to a friend using this dialogue as inspiration!',
              style: GoogleFonts.manrope(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: AppTheme.warning,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
